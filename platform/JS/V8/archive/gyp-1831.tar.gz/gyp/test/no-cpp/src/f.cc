extern "C" { void* f(); }

void* f() { return new int; }
