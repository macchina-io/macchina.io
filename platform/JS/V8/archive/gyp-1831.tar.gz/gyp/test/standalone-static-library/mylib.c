#include <stdio.h>

void print(void)
{
  printf("hello from mylib.c\n");
  return;
}
