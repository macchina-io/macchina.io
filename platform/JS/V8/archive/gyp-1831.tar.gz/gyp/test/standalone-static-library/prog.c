extern void print(void);

int main(int argc, char *argv[])
{
  print();
  return 0;
}
