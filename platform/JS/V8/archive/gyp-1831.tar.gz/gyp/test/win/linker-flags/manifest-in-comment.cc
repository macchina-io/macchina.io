// Copyright 2013 Google Inc. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#pragma comment(linker,                                                  \
                "\"/manifestdependency:type='Win32' "                    \
                "name='Test.Research.SampleAssembly' version='6.0.0.0' " \
                "processorArchitecture='X86' "                           \
                "publicKeyToken='0000000000000000' language='*'\"")

int main() {
  return 0;
}
