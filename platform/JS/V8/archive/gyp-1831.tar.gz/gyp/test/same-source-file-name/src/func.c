#include <stdio.h>

void func(void)
{
  printf("Hello %s from func.c\n", PROG);
}
