extern const char kSharedStr[];
