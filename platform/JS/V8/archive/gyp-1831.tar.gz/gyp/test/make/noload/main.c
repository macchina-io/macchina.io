#include <stdio.h>

#include "lib/shared.h"

int main(int argc, char *argv[])
{
  printf("Hello from %s.\n", kSharedStr);
  return 0;
}
