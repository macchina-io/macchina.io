int f() { return 0; }
